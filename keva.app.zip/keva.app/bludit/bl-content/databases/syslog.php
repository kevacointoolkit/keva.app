<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
[
    {
        "date": "2020-07-06 04:26:01",
        "dictionaryKey": "settings-changes",
        "notes": "",
        "idExecution": "5f023759aa85e",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-06 04:25:33",
        "dictionaryKey": "settings-changes",
        "notes": "",
        "idExecution": "5f02373d95369",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2020-07-06 04:24:34",
        "dictionaryKey": "plugin-deactivated",
        "notes": "TinyMCE",
        "idExecution": "5f023702e156f",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-06 04:24:30",
        "dictionaryKey": "plugin-deactivated",
        "notes": "Canonical",
        "idExecution": "5f0236fe22acc",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-06 04:24:26",
        "dictionaryKey": "plugin-deactivated",
        "notes": "API",
        "idExecution": "5f0236fa0137b",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-05 20:13:16",
        "dictionaryKey": "new-theme-configured",
        "notes": "alternative",
        "idExecution": "5f01c3dc299f1",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-05 20:07:36",
        "dictionaryKey": "new-theme-configured",
        "notes": "alternative",
        "idExecution": "5f01c28894004",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-05 20:06:51",
        "dictionaryKey": "new-theme-configured",
        "notes": "",
        "idExecution": "5f01c25b1cff5",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-05 20:06:50",
        "dictionaryKey": "new-theme-configured",
        "notes": "",
        "idExecution": "5f01c25ae4465",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2020-07-05 20:06:50",
        "dictionaryKey": "new-theme-configured",
        "notes": "",
        "idExecution": "5f01c25aad3a2",
        "method": "GET",
        "username": "admin"
    }
]