<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "general": {
        "name": "General",
        "description": "",
        "template": "",
        "list": []
    },
    "music": {
        "name": "Music",
        "description": "",
        "template": "",
        "list": []
    },
    "videos": {
        "name": "Videos",
        "description": "",
        "template": "",
        "list": []
    }
}