<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "admin": {
        "nickname": "Admin",
        "firstName": "Administrator",
        "lastName": "",
        "role": "admin",
        "password": "b7fc930c1cd3a7c2f98c85c3df7cd6e31c9ad495",
        "salt": "5f0199694249d",
        "email": "",
        "registered": "2020-07-05 17:12:09",
        "tokenRemember": "8e171562cbf3bea8849f6dd48e7cdfa3",
        "tokenAuth": "9caf211b1b1e1a1725285313964c43aa",
        "tokenAuthTTL": "2009-03-15 14:00",
        "twitter": "",
        "facebook": "",
        "instagram": "",
        "codepen": "",
        "linkedin": "",
        "github": "",
        "gitlab": "",
        "description": "",
        "mastodon": "",
        "vk": ""
    }
}