<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "hello": {
        "title": "hello",
        "description": "",
        "username": "admin",
        "tags": [],
        "type": "published",
        "date": "2020-07-05 18:12:24",
        "dateModified": "",
        "position": 2,
        "coverImage": "",
        "category": "",
        "md5file": "905b782c4066c4c1752d5df4da941582",
        "uuid": "50dfff268efcb0668f504ad39c4df5a0",
        "allowComments": true,
        "template": "",
        "noindex": false,
        "nofollow": false,
        "noarchive": false,
        "custom": [
            false
        ]
    }
}