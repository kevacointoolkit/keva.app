<?php
// This file is executed only the fist time when you activate the theme.

// Activate API plugin
activatePlugin('pluginAPI');

?>