It couldn't be better.

Live demo: https://oldpc.mrcyjanek.net/blog/why-does-this-website-look-like-this
