  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="theme-color" content="#000000">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <?php echo Theme::metaTags('title'); ?>
  <?php echo Theme::css('css/style.css'); ?>
  <?php echo Theme::favicon('img/favicon.png'); ?>
  <?php Theme::plugins('siteHead'); ?>
