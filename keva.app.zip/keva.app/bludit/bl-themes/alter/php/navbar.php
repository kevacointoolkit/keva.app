<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark text-uppercase">
	<div class="container">
		<a class="navbar-brand" href="<?php echo Theme::siteUrl(); ?>">
			<span class="text-white"><font color=#28f428><?php echo $site->title(); ?></font></span>
		</a><?php include("theme.php"); ?>
		
		<div class="collapse navbar-collapse" id="navbarResponsive">

			

		</div>
	</div>
</nav>
